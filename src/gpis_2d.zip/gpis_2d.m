% Script for generating a 2d GPIS
% INSTRUCTIONS:
%   1. Specify a type of shape
%   2. Click surface, interior, and exterior points using GUI to generate
%   the TSDF
%   3. Create GPIS representation
%   4. Predict values for the entire space and threshold to find the surface
clear; clc; close all;

%% Collect manually specified tsdf
shape = 'Circles';
gridDim = 100;
[points, tsdf] = manual_tsdf(shape, gridDim);

%% Attempt to create a gpis representation from the samples
numIters = 30;
thresh = 0.075;
gpModel = create_gpis(points, tsdf, numIters);
[testPoints, testTsdf, testVars, surfacePoints, surfaceTsdf, surfaceVars] = ...
    predict_2d_grid(gpModel, gridDim, thresh);

